"""Stages 3 & 4: rank likely root causes and identify missing evidence.

Both live here because they come from a single LLM call — asking the model to
produce ranked hypotheses *and* the evidence gaps in one structured response is
cheaper and keeps the two views consistent with each other.
"""

from __future__ import annotations

from .context import render_context_for_llm
from .llm import AnthropicClient
from .models import (
    Confidence,
    EvidenceRequest,
    Hypothesis,
    ParsedTraceback,
)

SYSTEM_PROMPT = """\
You are a meticulous senior software engineer performing root-cause analysis on \
a Python failure. You reason probabilistically: real bugs are uncertain, so you \
produce a RANKED list of candidate causes with calibrated probabilities, not a \
single confident guess.

You are honest about what you cannot see. When a diagnosis hinges on information \
absent from the traceback and source (a variable's runtime value, a dependency \
version, the triggering input, external service state), you request that \
evidence explicitly instead of guessing.

Respond with a single JSON object and nothing else, matching this schema:
{
  "hypotheses": [
    {
      "title": "short cause label",
      "explanation": "why this is plausible, grounded in the trace/source",
      "confidence": "high" | "medium" | "low",
      "probability": 0.0-1.0,
      "suggested_fix": "concrete fix or null",
      "implicated_frames": [<integer frame indices>]
    }
  ],
  "evidence_requests": [
    {"what": "...", "why": "...", "how": "..."}
  ]
}
Probabilities across hypotheses should sum to roughly 1.0. Order hypotheses \
most-likely first. Include 1-4 hypotheses and 0-4 evidence requests.\
"""


def _build_user_prompt(tb: ParsedTraceback) -> str:
    context = render_context_for_llm(tb)
    return (
        f"Exception: {tb.exception_type}: {tb.exception_message}\n\n"
        f"Traceback frames (deepest last), with source context:\n\n"
        f"{context}\n\n"
        f"Raw traceback:\n{tb.raw.strip()}\n"
    )


def _coerce_confidence(value: str) -> Confidence:
    try:
        return Confidence(str(value).lower())
    except ValueError:
        return Confidence.LOW


def rank_causes(
    tb: ParsedTraceback, client: AnthropicClient | None = None
) -> tuple[list[Hypothesis], list[EvidenceRequest]]:
    """Return ranked hypotheses and evidence requests for ``tb``."""
    client = client or AnthropicClient()
    data = client.complete_json(SYSTEM_PROMPT, _build_user_prompt(tb))

    hypotheses: list[Hypothesis] = []
    for h in data.get("hypotheses", []):
        try:
            prob = float(h.get("probability", 0.0))
        except (TypeError, ValueError):
            prob = 0.0
        hypotheses.append(
            Hypothesis(
                title=str(h.get("title", "Unlabeled cause")).strip(),
                explanation=str(h.get("explanation", "")).strip(),
                confidence=_coerce_confidence(h.get("confidence", "low")),
                probability=max(0.0, min(1.0, prob)),
                suggested_fix=(h.get("suggested_fix") or None),
                implicated_frames=[
                    int(i) for i in h.get("implicated_frames", []) if _is_int(i)
                ],
            )
        )

    # Normalize probabilities so they sum to 1.0 (if any are present).
    total = sum(h.probability for h in hypotheses)
    if total > 0:
        for h in hypotheses:
            h.probability = round(h.probability / total, 3)
    hypotheses.sort(key=lambda h: h.probability, reverse=True)

    evidence = [
        EvidenceRequest(
            what=str(e.get("what", "")).strip(),
            why=str(e.get("why", "")).strip(),
            how=str(e.get("how", "")).strip(),
        )
        for e in data.get("evidence_requests", [])
        if e.get("what")
    ]
    return hypotheses, evidence


def _is_int(value: object) -> bool:
    try:
        int(value)  # type: ignore[arg-type]
        return True
    except (TypeError, ValueError):
        return False
