"""Command-line interface for the AI Stack Trace Investigator.

Examples:
    # Analyze a traceback piped from a failing command
    python failing_app.py 2>&1 | investigate --project-root .

    # Analyze a saved traceback and attempt Docker reproduction
    investigate -f crash.txt --project-root . --repro app.py

    # Parse-only (no API key needed), emit JSON
    investigate -f crash.txt --no-llm --json
"""

from __future__ import annotations

import argparse
import sys

from .llm import LLMError
from .pipeline import investigate
from .report import to_json, to_text


def _read_input(path: str | None) -> str:
    if path:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    if sys.stdin.isatty():
        raise SystemExit(
            "No input. Provide -f FILE or pipe a traceback via stdin."
        )
    return sys.stdin.read()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="investigate",
        description="Analyze a Python stack trace, rank likely causes, request "
        "missing evidence, and optionally reproduce the failure in Docker.",
    )
    p.add_argument("-f", "--file", help="Path to a file containing the traceback.")
    p.add_argument(
        "--project-root",
        help="Repo root, used to resolve source and mount the sandbox.",
    )
    p.add_argument(
        "--repro",
        metavar="ENTRYPOINT",
        help="Script (relative to --project-root) to run in Docker to attempt "
        "reproduction, e.g. app.py.",
    )
    p.add_argument(
        "--repro-requirements",
        metavar="REQ_TXT",
        help="requirements.txt (relative to --project-root) to install before repro.",
    )
    p.add_argument(
        "--no-llm",
        action="store_true",
        help="Skip the LLM stage (parse + context only; no API key needed).",
    )
    p.add_argument(
        "--model",
        help="Override the Claude model (default: claude-sonnet-5 or "
        "$INVESTIGATOR_MODEL).",
    )
    p.add_argument("--json", action="store_true", help="Emit JSON instead of text.")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        raw = _read_input(args.file)
    except OSError as exc:
        print(f"error: could not read input: {exc}", file=sys.stderr)
        return 2

    client = None
    if not args.no_llm and args.model:
        from .llm import AnthropicClient

        client = AnthropicClient(model=args.model)

    try:
        inv = investigate(
            raw,
            project_root=args.project_root,
            client=client,
            skip_llm=args.no_llm,
            repro_entrypoint=args.repro,
            repro_requirements=args.repro_requirements,
        )
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except LLMError as exc:
        print(f"error (LLM): {exc}", file=sys.stderr)
        print(
            "hint: run with --no-llm for offline parsing, or set ANTHROPIC_API_KEY.",
            file=sys.stderr,
        )
        return 1

    print(to_json(inv) if args.json else to_text(inv))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
