"""Render an :class:`Investigation` as human-readable text or JSON."""

from __future__ import annotations

import dataclasses
import json

from .models import Investigation, ReproStatus

_BAR = "=" * 68


def to_dict(inv: Investigation) -> dict:
    """Serialize an investigation to a plain dict (JSON-ready)."""
    return dataclasses.asdict(inv)


def to_json(inv: Investigation, indent: int = 2) -> str:
    return json.dumps(to_dict(inv), indent=indent, default=str)


def _confidence_icon(prob: float) -> str:
    if prob >= 0.6:
        return "●●●"
    if prob >= 0.3:
        return "●●○"
    return "●○○"


def to_text(inv: Investigation) -> str:
    tb = inv.traceback
    out: list[str] = []
    out.append(_BAR)
    out.append("  AI STACK TRACE INVESTIGATOR")
    out.append(_BAR)
    out.append(f"Exception : {tb.exception_type}: {tb.exception_message}")
    crash = tb.crash_frame
    if crash:
        out.append(
            f"Origin    : {crash.filename}:{crash.lineno} in {crash.function}()"
        )
    out.append("")

    # Hypotheses
    if inv.hypotheses:
        out.append("LIKELY CAUSES (ranked)")
        out.append("-" * 68)
        for i, h in enumerate(inv.hypotheses, 1):
            pct = f"{h.probability * 100:4.0f}%"
            out.append(f"{i}. {_confidence_icon(h.probability)} [{pct}] {h.title}")
            out.append(f"     {h.explanation}")
            if h.suggested_fix:
                out.append(f"     Fix: {h.suggested_fix}")
            out.append("")
    else:
        out.append("(No hypotheses — LLM stage was skipped or returned nothing.)")
        out.append("")

    # Evidence requests
    if inv.evidence_requests:
        out.append("MISSING EVIDENCE (would sharpen the diagnosis)")
        out.append("-" * 68)
        for e in inv.evidence_requests:
            out.append(f"• {e.what}")
            out.append(f"    why : {e.why}")
            out.append(f"    how : {e.how}")
        out.append("")

    # Reproduction
    if inv.repro:
        out.append("SANDBOX REPRODUCTION")
        out.append("-" * 68)
        icon = {
            ReproStatus.REPRODUCED: "✓ reproduced",
            ReproStatus.DIFFERENT_FAILURE: "≠ different failure",
            ReproStatus.RAN_CLEAN: "○ ran clean (no error)",
            ReproStatus.SKIPPED: "– skipped",
            ReproStatus.ERROR: "! sandbox error",
        }.get(inv.repro.status, str(inv.repro.status))
        out.append(f"Status: {icon}")
        out.append(f"        {inv.repro.detail}")
        if inv.repro.stderr.strip():
            tail = "\n".join(inv.repro.stderr.strip().splitlines()[-6:])
            out.append("        stderr (tail):")
            for line in tail.splitlines():
                out.append(f"          {line}")
        out.append("")

    out.append(_BAR)
    return "\n".join(out)
