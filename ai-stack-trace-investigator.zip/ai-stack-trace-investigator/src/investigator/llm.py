"""Thin wrapper around the Anthropic Messages API.

Kept separate from the analysis logic so it can be mocked in tests and so a
different provider could be dropped in later without touching the ranker.
"""

from __future__ import annotations

import json
import os
from typing import Any

DEFAULT_MODEL = "claude-sonnet-5"
DEFAULT_MAX_TOKENS = 2048


class LLMError(RuntimeError):
    """Raised when the LLM call fails or returns unusable output."""


class AnthropicClient:
    """Minimal Claude client that returns parsed JSON from a prompt.

    The API key is read from the ``ANTHROPIC_API_KEY`` environment variable.
    """

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
    ) -> None:
        self.model = model or os.getenv("INVESTIGATOR_MODEL", DEFAULT_MODEL)
        self.max_tokens = max_tokens
        self._api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self._client = None  # lazily constructed

    def _ensure_client(self) -> Any:
        if self._client is not None:
            return self._client
        if not self._api_key:
            raise LLMError(
                "ANTHROPIC_API_KEY is not set. Export it or pass api_key=..."
            )
        try:
            import anthropic  # imported lazily so the parser works without it
        except ImportError as exc:  # pragma: no cover
            raise LLMError(
                "The 'anthropic' package is required. Install with "
                "`pip install anthropic`."
            ) from exc
        self._client = anthropic.Anthropic(api_key=self._api_key)
        return self._client

    def complete_json(self, system: str, user: str) -> dict:
        """Send a prompt and parse the model's reply as a JSON object.

        We instruct the model to return raw JSON, then defensively strip any
        stray code fences before parsing.
        """
        client = self._ensure_client()
        try:
            resp = client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
        except Exception as exc:  # noqa: BLE001 - surface any SDK error uniformly
            raise LLMError(f"Anthropic API call failed: {exc}") from exc

        text = "".join(
            block.text for block in resp.content if getattr(block, "type", "") == "text"
        ).strip()
        return _parse_json_lenient(text)


def _parse_json_lenient(text: str) -> dict:
    """Parse JSON that may be wrapped in ```json fences or have prose around it."""
    cleaned = text.strip()
    if cleaned.startswith("```"):
        # Drop the first fence line and any trailing fence.
        cleaned = cleaned.split("\n", 1)[-1]
        if cleaned.rstrip().endswith("```"):
            cleaned = cleaned.rsplit("```", 1)[0]
    cleaned = cleaned.strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Last resort: grab the outermost {...} span.
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(cleaned[start : end + 1])
            except json.JSONDecodeError as exc:
                raise LLMError(f"Could not parse JSON from model output: {exc}")
        raise LLMError("Model did not return valid JSON.")
