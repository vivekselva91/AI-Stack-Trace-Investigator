"""Core data models shared across the investigation pipeline.

These are intentionally plain dataclasses (no external deps) so every stage of
the pipeline speaks the same language and stays independently testable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


@dataclass
class Frame:
    """A single frame in a parsed Python traceback."""

    filename: str
    lineno: int
    function: str
    code: Optional[str] = None  # the source line of code, if captured
    # Populated later by the context stage: surrounding source lines.
    source_context: Optional[str] = None
    # True if this frame lives in the user's project (vs. site-packages/stdlib).
    in_project: bool = False


@dataclass
class ParsedTraceback:
    """Structured representation of a raw Python traceback string."""

    exception_type: str
    exception_message: str
    frames: list[Frame] = field(default_factory=list)
    raw: str = ""

    @property
    def crash_frame(self) -> Optional[Frame]:
        """The deepest in-project frame, or the deepest frame overall.

        This is usually where the investigation should start looking.
        """
        for frame in reversed(self.frames):
            if frame.in_project:
                return frame
        return self.frames[-1] if self.frames else None


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class Hypothesis:
    """A single candidate root cause, as ranked by the analysis stage."""

    title: str
    explanation: str
    confidence: Confidence
    probability: float  # 0.0 - 1.0, normalized across all hypotheses
    suggested_fix: Optional[str] = None
    # Which frame(s) this hypothesis points at, by index into the traceback.
    implicated_frames: list[int] = field(default_factory=list)


@dataclass
class EvidenceRequest:
    """A piece of missing context that would sharpen the diagnosis."""

    what: str          # e.g. "The value of `config` at line 42"
    why: str           # e.g. "To confirm whether the KeyError is a missing env var"
    how: str           # e.g. "Re-run with STACKTRACE_DEBUG=1 or paste the config dict"


class ReproStatus(str, Enum):
    REPRODUCED = "reproduced"          # same exception type reproduced
    DIFFERENT_FAILURE = "different"    # it failed, but not the same way
    RAN_CLEAN = "ran_clean"            # code ran without error
    SKIPPED = "skipped"                # not attempted
    ERROR = "error"                    # the sandbox itself failed


@dataclass
class ReproResult:
    status: ReproStatus
    detail: str = ""
    stdout: str = ""
    stderr: str = ""
    exit_code: Optional[int] = None
    matched_exception: bool = False


@dataclass
class Investigation:
    """The full output of a run — this is what gets rendered/serialized."""

    traceback: ParsedTraceback
    hypotheses: list[Hypothesis] = field(default_factory=list)
    evidence_requests: list[EvidenceRequest] = field(default_factory=list)
    repro: Optional[ReproResult] = None
    notes: str = ""
