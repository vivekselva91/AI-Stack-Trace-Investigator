"""Orchestrator: wires the five stages into one investigation.

    parse -> attach source context -> rank causes / find evidence gaps
          -> (optional) reproduce in sandbox

Each stage is independently useful, so callers can also import and run them
individually. This module is the convenience path used by the CLI.
"""

from __future__ import annotations

from .context import attach_source_context
from .llm import AnthropicClient
from .models import Investigation, ReproResult, ReproStatus
from .parser import parse_traceback
from .ranker import rank_causes
from .sandbox import reproduce


def investigate(
    raw_traceback: str,
    *,
    project_root: str | None = None,
    client: AnthropicClient | None = None,
    skip_llm: bool = False,
    repro_entrypoint: str | None = None,
    repro_requirements: str | None = None,
) -> Investigation:
    """Run the full investigation pipeline over a raw traceback string.

    Args:
        raw_traceback: the traceback text (from a log, terminal, CI, etc.).
        project_root: repo root, used to resolve source files and mount the
            sandbox. Optional but strongly recommended for good results.
        client: an :class:`AnthropicClient`; constructed on demand if omitted.
        skip_llm: parse and gather context only (useful for offline/testing).
        repro_entrypoint: script (relative to project_root) to run in Docker to
            attempt reproduction. If omitted, reproduction is skipped.
        repro_requirements: optional requirements.txt (relative to root).
    """
    tb = parse_traceback(raw_traceback, project_root=project_root)
    attach_source_context(tb, project_root=project_root)

    investigation = Investigation(traceback=tb)

    if not skip_llm:
        hypotheses, evidence = rank_causes(tb, client=client)
        investigation.hypotheses = hypotheses
        investigation.evidence_requests = evidence

    if repro_entrypoint and project_root:
        investigation.repro = reproduce(
            tb,
            project_root=project_root,
            entrypoint=repro_entrypoint,
            requirements=repro_requirements,
        )
    else:
        investigation.repro = ReproResult(
            status=ReproStatus.SKIPPED,
            detail="No repro entrypoint provided; reproduction not attempted.",
        )

    return investigation
