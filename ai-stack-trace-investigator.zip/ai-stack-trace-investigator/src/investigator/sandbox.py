"""Stage 5: best-effort failure reproduction in an isolated Docker container.

Security posture (treat repro targets as hostile-adjacent):
  * no network            (--network none)
  * non-root user         (--user)
  * read-only project mount
  * capped memory & CPU
  * hard wall-clock timeout
  * no new privileges

Reproduction only makes sense for self-contained, deterministic failures. When
the environment can't be reconstructed (external DBs, services, missing inputs),
this stage degrades gracefully and reports SKIPPED/ERROR rather than pretending.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .models import ParsedTraceback, ReproResult, ReproStatus

DEFAULT_IMAGE = "python:3.12-slim"
DEFAULT_TIMEOUT = 30  # seconds
DEFAULT_MEMORY = "256m"
DEFAULT_CPUS = "1.0"


def docker_available() -> bool:
    """True if a usable docker CLI is on PATH and the daemon responds."""
    if shutil.which("docker") is None:
        return False
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


def reproduce(
    tb: ParsedTraceback,
    project_root: str,
    entrypoint: str,
    *,
    image: str = DEFAULT_IMAGE,
    requirements: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
    memory: str = DEFAULT_MEMORY,
    cpus: str = DEFAULT_CPUS,
) -> ReproResult:
    """Attempt to reproduce ``tb`` by running ``entrypoint`` inside a container.

    Args:
        tb: the parsed traceback we're trying to reproduce.
        project_root: host directory mounted read-only into the container.
        entrypoint: path (relative to project_root) of the script to run,
            e.g. "app.py". Its arguments, if any, should be baked into the
            script or provided via a repro harness.
        requirements: optional path to a requirements.txt to install first.

    Returns:
        A :class:`ReproResult` describing what happened.
    """
    if not docker_available():
        return ReproResult(
            status=ReproStatus.SKIPPED,
            detail="Docker is not available on this host; skipping reproduction.",
        )

    root = Path(project_root).resolve()
    if not root.is_dir():
        return ReproResult(
            status=ReproStatus.ERROR,
            detail=f"project_root does not exist: {root}",
        )
    if not (root / entrypoint).is_file():
        return ReproResult(
            status=ReproStatus.ERROR,
            detail=f"entrypoint not found under project root: {entrypoint}",
        )

    # Build the in-container command. Install requirements (if any) then run.
    install = ""
    if requirements and (root / requirements).is_file():
        install = f"pip install --no-cache-dir -q -r /work/{requirements} && "
    inner_cmd = f"{install}python /work/{entrypoint}"

    docker_cmd = [
        "docker", "run", "--rm",
        "--network", "none",
        "--memory", memory,
        "--cpus", cpus,
        "--pids-limit", "128",
        "--security-opt", "no-new-privileges",
        "--user", "1000:1000",
        "--read-only",
        "--tmpfs", "/tmp:size=64m",
        "-v", f"{root}:/work:ro",
        "-w", "/work",
        image,
        "sh", "-c", inner_cmd,
    ]

    try:
        proc = subprocess.run(
            docker_cmd,
            capture_output=True,
            text=True,
            timeout=timeout + 15,  # allow docker startup overhead
        )
    except subprocess.TimeoutExpired:
        return ReproResult(
            status=ReproStatus.ERROR,
            detail=f"Reproduction timed out after {timeout}s.",
        )
    except (subprocess.SubprocessError, OSError) as exc:
        return ReproResult(status=ReproStatus.ERROR, detail=str(exc))

    stdout, stderr = proc.stdout, proc.stderr

    if proc.returncode == 0:
        return ReproResult(
            status=ReproStatus.RAN_CLEAN,
            detail="Entrypoint ran to completion without raising.",
            stdout=stdout,
            stderr=stderr,
            exit_code=0,
        )

    matched = tb.exception_type in stderr
    return ReproResult(
        status=ReproStatus.REPRODUCED if matched else ReproStatus.DIFFERENT_FAILURE,
        detail=(
            f"Reproduced {tb.exception_type}."
            if matched
            else "Failed, but with a different exception than the original."
        ),
        stdout=stdout,
        stderr=stderr,
        exit_code=proc.returncode,
        matched_exception=matched,
    )
