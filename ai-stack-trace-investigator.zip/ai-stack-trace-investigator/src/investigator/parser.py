"""Stage 1: parse a raw Python traceback string into structured data.

This handles the standard CPython traceback format::

    Traceback (most recent call last):
      File "app.py", line 10, in <module>
        main()
      File "app.py", line 6, in main
        return load_config()["port"]
    KeyError: 'port'

It is deliberately forgiving: real-world tracebacks arrive with log-line
prefixes, ANSI colors, and chained exceptions ("During handling of the above
exception..."). We extract the *last* exception in a chain by default, since
that is usually the one the user cares about, while keeping the full raw text.
"""

from __future__ import annotations

import os
import re

from .models import Frame, ParsedTraceback

# "  File "path", line N, in func"
_FILE_RE = re.compile(
    r'^\s*File "(?P<file>.+?)", line (?P<line>\d+), in (?P<func>.+?)\s*$'
)
# Final "ExceptionType: message" line. Type must be a dotted identifier.
_EXC_RE = re.compile(
    r"^(?P<type>[A-Za-z_][\w.]*(?:Error|Exception|Warning|Interrupt|Exit|Iteration|"
    r"Timeout|NotImplemented|Failure|Fault|[A-Z]\w+))(?::\s?(?P<msg>.*))?$"
)

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
_TB_HEADER = "Traceback (most recent call last):"


def _strip_noise(line: str) -> str:
    """Remove ANSI color codes and common logging prefixes from a line."""
    line = _ANSI_RE.sub("", line)
    # Strip a leading log prefix like "2024-01-01 12:00:00,123 ERROR | "
    # but only up to a 'Traceback'/'File'/exception marker to avoid eating code.
    return line.rstrip("\n")


def _is_project_path(path: str, project_root: str | None) -> bool:
    """Heuristic: does this frame belong to the user's code?"""
    if "site-packages" in path or "dist-packages" in path:
        return False
    lib = os.sep + "lib" + os.sep + "python"
    if lib in path:
        return False
    if project_root:
        try:
            return os.path.abspath(path).startswith(os.path.abspath(project_root))
        except (ValueError, OSError):
            return False
    # Without a known root, assume relative/bare filenames are project code.
    return not os.path.isabs(path)


def parse_traceback(
    raw: str, project_root: str | None = None
) -> ParsedTraceback:
    """Parse ``raw`` into a :class:`ParsedTraceback`.

    Raises:
        ValueError: if no recognizable traceback is found.
    """
    lines = [_strip_noise(ln) for ln in raw.splitlines()]

    # Find the LAST traceback header (handles chained exceptions).
    header_idxs = [i for i, ln in enumerate(lines) if _TB_HEADER in ln]
    start = header_idxs[-1] + 1 if header_idxs else 0

    frames: list[Frame] = []
    exc_type: str | None = None
    exc_msg = ""

    i = start
    while i < len(lines):
        line = lines[i]
        m = _FILE_RE.match(line)
        if m:
            code = None
            # The following indented line (if present and not another File/exc)
            # is the source code for this frame.
            if i + 1 < len(lines):
                nxt = lines[i + 1]
                if nxt.strip() and not _FILE_RE.match(nxt) and "File \"" not in nxt:
                    if not _looks_like_exception(nxt):
                        code = nxt.strip()
                        i += 1
            path = m.group("file")
            frames.append(
                Frame(
                    filename=path,
                    lineno=int(m.group("line")),
                    function=m.group("func"),
                    code=code,
                    in_project=_is_project_path(path, project_root),
                )
            )
            i += 1
            continue

        # Look for the terminating exception line once we've seen frames.
        if frames and _looks_like_exception(line):
            em = _EXC_RE.match(line.strip())
            if em:
                exc_type = em.group("type")
                exc_msg = (em.group("msg") or "").strip()
                break
        i += 1

    if not frames or exc_type is None:
        # Fall back: maybe there's a bare "Type: message" with no frames.
        for line in reversed(lines):
            em = _EXC_RE.match(line.strip())
            if em and _looks_like_exception(line):
                exc_type = em.group("type")
                exc_msg = (em.group("msg") or "").strip()
                break

    if exc_type is None:
        raise ValueError(
            "No recognizable Python traceback found in the provided text."
        )

    return ParsedTraceback(
        exception_type=exc_type,
        exception_message=exc_msg,
        frames=frames,
        raw=raw,
    )


def _looks_like_exception(line: str) -> bool:
    """Cheap check that a line is a 'SomeError: message' terminator."""
    stripped = line.strip()
    if not stripped or stripped.startswith("File "):
        return False
    m = _EXC_RE.match(stripped)
    return bool(m)
