"""AI Stack Trace Investigator.

An LLM-assisted pipeline that parses Python stack traces, ranks likely root
causes with calibrated probabilities, asks for missing evidence instead of
guessing, and (best-effort) reproduces failures in an isolated Docker sandbox.
"""

from .models import (
    Confidence,
    EvidenceRequest,
    Frame,
    Hypothesis,
    Investigation,
    ParsedTraceback,
    ReproResult,
    ReproStatus,
)
from .parser import parse_traceback
from .pipeline import investigate

__version__ = "0.1.0"

__all__ = [
    "investigate",
    "parse_traceback",
    "Investigation",
    "ParsedTraceback",
    "Frame",
    "Hypothesis",
    "EvidenceRequest",
    "Confidence",
    "ReproResult",
    "ReproStatus",
    "__version__",
]
