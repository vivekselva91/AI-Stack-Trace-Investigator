"""Stage 2: enrich parsed frames with real source code from the repo.

The traceback tells us *where* things broke; this stage pulls the surrounding
lines from disk so the LLM ranker reasons about actual code rather than a single
quoted line. Frames whose files we cannot locate are left untouched.
"""

from __future__ import annotations

import os

from .models import ParsedTraceback


def _resolve_path(filename: str, project_root: str | None) -> str | None:
    """Try to find the on-disk path for a frame's filename."""
    if os.path.isfile(filename):
        return filename
    if project_root:
        candidate = os.path.join(project_root, filename)
        if os.path.isfile(candidate):
            return candidate
        # Try matching by basename anywhere under the root (last resort).
        base = os.path.basename(filename)
        for dirpath, _dirs, files in os.walk(project_root):
            if base in files:
                return os.path.join(dirpath, base)
    return None


def attach_source_context(
    tb: ParsedTraceback,
    project_root: str | None = None,
    window: int = 5,
) -> ParsedTraceback:
    """Populate ``frame.source_context`` with ``window`` lines around each frame.

    Mutates and returns ``tb`` for convenience.
    """
    for frame in tb.frames:
        path = _resolve_path(frame.filename, project_root)
        if not path:
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                source_lines = fh.readlines()
        except OSError:
            continue

        frame.source_context = _extract_window(
            source_lines, frame.lineno, window
        )
    return tb


def _extract_window(source_lines: list[str], lineno: int, window: int) -> str:
    """Return a numbered snippet centered on ``lineno`` (1-indexed)."""
    start = max(0, lineno - window - 1)
    end = min(len(source_lines), lineno + window)
    out = []
    for idx in range(start, end):
        marker = ">>" if (idx + 1) == lineno else "  "
        out.append(f"{marker} {idx + 1:>5} | {source_lines[idx].rstrip()}")
    return "\n".join(out)


def render_context_for_llm(tb: ParsedTraceback, max_frames: int = 8) -> str:
    """Produce a compact, LLM-friendly rendering of frames + source.

    Prioritizes in-project frames and the deepest frames, capping total size.
    """
    # Rank frames: in-project first, then by depth (deepest = most relevant).
    indexed = list(enumerate(tb.frames))
    indexed.sort(key=lambda p: (not p[1].in_project, -p[0]))
    chosen = sorted(indexed[:max_frames], key=lambda p: p[0])

    blocks = []
    for idx, frame in chosen:
        tag = "PROJECT" if frame.in_project else "library"
        header = (
            f"[frame {idx}] ({tag}) {frame.filename}:{frame.lineno} "
            f"in {frame.function}()"
        )
        body = frame.source_context or (
            f"        {frame.code}" if frame.code else "        <source unavailable>"
        )
        blocks.append(f"{header}\n{body}")
    return "\n\n".join(blocks)
