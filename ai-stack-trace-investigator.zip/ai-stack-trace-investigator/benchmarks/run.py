"""Benchmark harness: scores diagnosis quality and reproduction over cases/.

Usage:
    python -m benchmarks.run --repro-only     # no API key required
    python -m benchmarks.run                  # full run (needs ANTHROPIC_API_KEY)
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from investigator.parser import parse_traceback
from investigator.pipeline import investigate
from investigator.sandbox import docker_available, reproduce

CASES_DIR = Path(__file__).parent / "cases"


def _load_case(case_dir: Path) -> dict:
    expected = json.loads((case_dir / "expected.json").read_text())
    traceback = (case_dir / "traceback.txt").read_text()
    return {"dir": case_dir, "expected": expected, "traceback": traceback}


def _diagnosis_hit(top_hypothesis_text: str, keywords: list[str]) -> bool:
    text = top_hypothesis_text.lower()
    return any(kw.lower() in text for kw in keywords)


def run(repro_only: bool) -> int:
    cases = sorted(
        p for p in CASES_DIR.iterdir() if p.is_dir() and (p / "expected.json").exists()
    )
    if not cases:
        print("No benchmark cases found.")
        return 1

    have_docker = docker_available()
    diag_hits = diag_total = repro_hits = repro_total = 0

    print(f"{'case':<28} {'diagnosis':<12} {'reproduction':<14}")
    print("-" * 56)

    for case_dir in cases:
        case = _load_case(case_dir)
        exp = case["expected"]
        name = case_dir.name

        diag_cell = "—"
        if not repro_only:
            try:
                inv = investigate(
                    case["traceback"], project_root=str(case_dir)
                )
                diag_total += 1
                top = inv.hypotheses[0] if inv.hypotheses else None
                text = f"{top.title} {top.explanation}" if top else ""
                hit = _diagnosis_hit(text, exp["expected_root_cause_keywords"])
                diag_hits += int(hit)
                diag_cell = "✓" if hit else "✗"
            except Exception as exc:  # noqa: BLE001
                diag_cell = f"err:{type(exc).__name__}"
        else:
            # Still verify the parser understands the traceback.
            parse_traceback(case["traceback"], project_root=str(case_dir))

        repro_cell = "—"
        if exp.get("reproducible") and exp.get("entrypoint"):
            if not have_docker:
                repro_cell = "no-docker"
            else:
                repro_total += 1
                tb = parse_traceback(case["traceback"], project_root=str(case_dir))
                result = reproduce(
                    tb,
                    project_root=str(case_dir),
                    entrypoint=exp["entrypoint"],
                )
                ok = result.matched_exception
                repro_hits += int(ok)
                repro_cell = "✓" if ok else result.status.value

        print(f"{name:<28} {diag_cell:<12} {repro_cell:<14}")

    print("-" * 56)
    if not repro_only and diag_total:
        print(f"Diagnosis    : {diag_hits}/{diag_total}")
    if repro_total:
        print(f"Reproduction : {repro_hits}/{repro_total}")
    elif not have_docker:
        print("Reproduction : skipped (Docker unavailable)")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the investigator benchmark.")
    parser.add_argument(
        "--repro-only",
        action="store_true",
        help="Skip the LLM diagnosis; only test parsing + reproduction.",
    )
    raise SystemExit(run(parser.parse_args().repro_only))
