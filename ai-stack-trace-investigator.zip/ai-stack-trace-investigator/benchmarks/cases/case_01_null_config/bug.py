"""A config loader that assumes a key always exists."""


def load_config() -> dict:
    # In production this would read from a file/env; the 'port' key is missing.
    return {"host": "localhost"}


def start_server() -> None:
    config = load_config()
    port = config["port"]  # KeyError: 'port'
    print(f"starting on {port}")


if __name__ == "__main__":
    start_server()
