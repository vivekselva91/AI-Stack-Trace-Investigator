"""Off-by-one when reading the last element."""


def last_item(items: list) -> int:
    # Bug: should be items[-1] or items[len(items) - 1]
    return items[len(items)]


if __name__ == "__main__":
    print(last_item([10, 20, 30]))
