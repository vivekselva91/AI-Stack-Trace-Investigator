# Benchmark Suite

A small, growing set of **known bugs with known root causes**. Each case lets us
measure two things objectively:

1. **Diagnosis quality** — does the top-ranked hypothesis mention the real cause?
2. **Reproduction** — can the sandbox reproduce the original exception?

## Layout

Each case is a directory under `cases/`:

```
cases/case_XX_name/
├── bug.py          # a self-contained, deterministic failure
├── traceback.txt   # the traceback it produces
└── expected.json   # exception type, root-cause keywords, repro info
```

`expected.json` schema:

| field                          | meaning                                             |
|--------------------------------|-----------------------------------------------------|
| `exception_type`               | the exception the case should raise                 |
| `expected_root_cause_keywords` | any-of keywords the top hypothesis should mention   |
| `reproducible`                 | whether the sandbox should reproduce it             |
| `entrypoint`                   | script to run for reproduction                      |

## Running

```bash
# Reproduction-only scoring (no API key needed):
python -m benchmarks.run --repro-only

# Full scoring including LLM diagnosis (needs ANTHROPIC_API_KEY):
python -m benchmarks.run
```

The harness prints a per-case table and an aggregate score such as
`Diagnosis: 7/8 · Reproduction: 8/8`, which is exactly the kind of quantified
result worth putting in the top-level README.

## Adding a case

1. Write the smallest `bug.py` that deterministically fails.
2. Capture its traceback into `traceback.txt`.
3. Fill in `expected.json`.

Good cases are self-contained (no network, no external services) so the sandbox
can reproduce them reliably.
