"""Tests for the traceback parser — the deterministic core of the tool."""

import pytest

from investigator.parser import parse_traceback

SIMPLE = """\
Traceback (most recent call last):
  File "app.py", line 10, in <module>
    main()
  File "app.py", line 6, in main
    return load_config()["port"]
KeyError: 'port'
"""

CHAINED = """\
Traceback (most recent call last):
  File "a.py", line 2, in <module>
    risky()
ValueError: bad value

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "a.py", line 4, in <module>
    fallback()
RuntimeError: fallback also failed
"""

WITH_LOG_PREFIX = """\
2024-05-01 09:00:00,123 ERROR worker | Traceback (most recent call last):
  File "/srv/app/worker.py", line 42, in run
    process(item)
TypeError: unsupported operand type(s) for +: 'int' and 'str'
"""

SITE_PACKAGES = """\
Traceback (most recent call last):
  File "main.py", line 3, in <module>
    df.merge(other)
  File "/usr/lib/python3.12/site-packages/pandas/core/frame.py", line 9, in merge
    raise MergeError("no common columns")
pandas.errors.MergeError: no common columns
"""


def test_parses_exception_type_and_message():
    tb = parse_traceback(SIMPLE)
    assert tb.exception_type == "KeyError"
    assert tb.exception_message == "'port'"


def test_parses_all_frames_in_order():
    tb = parse_traceback(SIMPLE)
    assert len(tb.frames) == 2
    assert tb.frames[0].function == "<module>"
    assert tb.frames[1].function == "main"
    assert tb.frames[1].lineno == 6
    assert tb.frames[1].code == 'return load_config()["port"]'


def test_chained_exception_takes_last():
    tb = parse_traceback(CHAINED)
    assert tb.exception_type == "RuntimeError"
    assert "fallback also failed" in tb.exception_message
    assert tb.frames[-1].function == "<module>"


def test_tolerates_log_prefix():
    tb = parse_traceback(WITH_LOG_PREFIX)
    assert tb.exception_type == "TypeError"
    assert tb.frames[0].function == "run"


def test_crash_frame_prefers_project_code():
    tb = parse_traceback(SITE_PACKAGES)
    crash = tb.crash_frame
    assert crash is not None
    # The deepest *project* frame is main.py, not the pandas library frame.
    assert crash.filename == "main.py"
    assert tb.frames[1].in_project is False  # site-packages frame


def test_raises_on_garbage():
    with pytest.raises(ValueError):
        parse_traceback("this is not a traceback at all")
