"""Tests for the ranker, using a fake LLM client so no API key is needed."""

from investigator.models import Confidence
from investigator.parser import parse_traceback
from investigator.ranker import rank_causes

SIMPLE = """\
Traceback (most recent call last):
  File "app.py", line 6, in main
    return load_config()["port"]
KeyError: 'port'
"""


class FakeClient:
    """Stands in for AnthropicClient.complete_json."""

    def __init__(self, payload):
        self._payload = payload

    def complete_json(self, system, user):  # noqa: D401, ARG002
        return self._payload


def test_probabilities_are_normalized_and_sorted():
    payload = {
        "hypotheses": [
            {
                "title": "Low prob cause",
                "explanation": "x",
                "confidence": "low",
                "probability": 0.2,
            },
            {
                "title": "High prob cause",
                "explanation": "y",
                "confidence": "high",
                "probability": 0.6,
            },
        ],
        "evidence_requests": [],
    }
    tb = parse_traceback(SIMPLE)
    hyps, _ = rank_causes(tb, client=FakeClient(payload))

    # Sorted most-likely first.
    assert hyps[0].title == "High prob cause"
    # Normalized to sum to ~1.0.
    assert abs(sum(h.probability for h in hyps) - 1.0) < 1e-6


def test_bad_confidence_defaults_to_low():
    payload = {
        "hypotheses": [
            {"title": "t", "explanation": "e", "confidence": "banana",
             "probability": 1.0},
        ],
        "evidence_requests": [],
    }
    tb = parse_traceback(SIMPLE)
    hyps, _ = rank_causes(tb, client=FakeClient(payload))
    assert hyps[0].confidence == Confidence.LOW


def test_evidence_requests_are_parsed():
    payload = {
        "hypotheses": [],
        "evidence_requests": [
            {"what": "value of config", "why": "confirm key", "how": "print it"},
            {"what": "", "why": "ignored", "how": "ignored"},  # dropped (no 'what')
        ],
    }
    tb = parse_traceback(SIMPLE)
    _, evidence = rank_causes(tb, client=FakeClient(payload))
    assert len(evidence) == 1
    assert evidence[0].what == "value of config"
